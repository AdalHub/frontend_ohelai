// chatbotPage.js

import React, { useState, useEffect, useRef } from 'react';
import Header from '../components/Header';
import { FaUserCircle, FaPaperPlane } from 'react-icons/fa';
import '../styles/chatbotPage.css';
import logo from '../images/OhelAiLogo.jpeg'; // Ensure the path to your image is correct

function TestChat() {
  const [isDrawerOpen, setIsDrawerOpen] = useState(true);
  const [messages, setMessages] = useState([]);
  const [userInput, setUserInput] = useState('');
  const userEmail = localStorage.getItem('userEmail');
  const drawerRef = useRef();

  const toggleDrawer = () => {
    setIsDrawerOpen(!isDrawerOpen);
  };

  const fetchChatHistory = async () => {
    try {
      const response = await fetch('http://127.0.0.1:5000/history', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email: userEmail }),
      });
  
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
  
      const data = await response.json();
      console.log('Chatbot response:', data); // Log chatbot response

      // Create a new array to maintain the flow of messages
      let newMessages = [];
      data.forEach(msg => {
        newMessages.push({ text: msg.user, sender: 'user' });
        newMessages.push({ text: msg.assistant, sender: 'bot' });
      });
      
      setMessages(newMessages); // Set the interleaved messages array
    } catch (error) {
      console.error('Error fetching chat history:', error);
      setMessages([]); // Set empty array in case of error
    }
  };

  const handleSend = async () => {
    if (userInput.trim()) {
      try {
        const userMsg = { text: userInput, sender: 'user' };
        setMessages(prevMessages => [...prevMessages, userMsg]); // Add user's message
  
        const response = await fetch('http://127.0.0.1:5000/chatbot', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ query: userInput, email: userEmail }),
        });
  
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
  
        const data = await response.json();
        console.log('Bot response:', data); // Log the bot's response
  
        const botResponse = { text: data, sender: 'bot' };
        console.log('Bot response:', botResponse);
  
        setMessages(prevMessages => [...prevMessages, botResponse]); // Add bot's response
        setUserInput(''); // Clear input after sending
      } catch (error) {
        console.error('Error:', error);
        // Handle error by adding an error message or similar
      }
    }
  };
  
  
  
  
  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault(); // Prevent the default action to avoid a line break in the textarea
      handleSend(); // Call your send function
    }
    // If Shift + Enter is pressed, a new line is added by the textarea's default behavior
  };

  useEffect(() => {
    fetchChatHistory();
  }, []); // Fetch chat history on component mount

  return (
    <div className="chatbot-page">
      <Header />
      <div className="drawer-chat-container">
        <div className={`side-drawer ${isDrawerOpen ? 'open' : ''}`} ref={drawerRef}>
          <div className="drawer-title">
            Chatbot Sessions
          </div>
        </div>
        <div className="chat-area-container">
          <h2 className="chat-title">OhelAI, your Smart and Safe Shopping Guru Media!</h2>
          <div className="messages-container">
            {messages.map((message, index) => (
              <div key={index} className={`message-row ${message.sender}`}>
                {message.sender === 'bot' ? (
                  <img src={logo} alt="Bot Logo" className="bot-icon" />
                ) : (
                  <FaUserCircle className="user-icon" />
                )}
                <div className={`message-bubble ${message.sender}`}>
                  <div className="message">{message.text}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="input-area">
            <textarea
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              placeholder="Type a message..."
              onKeyPress={handleKeyPress}
              rows={1} // This starts the textarea with a single line
              style={{ resize: 'none' }} // This prevents the textarea from being resized
            />
            <button className="send-btn" onClick={handleSend}>
              <FaPaperPlane size="1.5em" />
            </button>
          </div>
        </div>
        <button
          className={`toggle-btn ${isDrawerOpen ? 'button-shift' : ''}`}
          onClick={toggleDrawer}
        >
          {isDrawerOpen ? '<' : '>'}
        </button>
      </div>
    </div>
  );
}

export default TestChat;
